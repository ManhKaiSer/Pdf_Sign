using System;
using System.IO;

namespace Org.BouncyCastle.Asn1
{
	[Obsolete("Will be removed")]
	public class Asn1ObjectParser
	{
	}
}
